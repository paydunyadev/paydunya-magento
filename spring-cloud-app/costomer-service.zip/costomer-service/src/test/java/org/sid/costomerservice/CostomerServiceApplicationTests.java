package org.sid.costomerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CostomerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
